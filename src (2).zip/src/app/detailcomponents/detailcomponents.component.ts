import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailcomponents',
  templateUrl: './detailcomponents.component.html',
  styleUrls: ['./detailcomponents.component.css']
})
export class DetailcomponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
