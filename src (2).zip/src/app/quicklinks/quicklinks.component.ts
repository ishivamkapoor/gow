import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quicklinks',
  templateUrl: './quicklinks.component.html',
  styleUrls: ['./quicklinks.component.css']
})
export class QuicklinksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
